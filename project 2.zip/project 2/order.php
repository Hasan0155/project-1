<?php
//$link=mysqli_connect('localhost','root','');
//mysqli_select_db('cofeeshop'); 

$servername = "localhost";
$username = "root";
$password = "";
$dbname="customer";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";



$fullname=$_POST['fullname'];
$Email=$_POST['mail'];
$mobile=$_POST['mobile'];
$gender=$_POST['gender'];
$table_no=$_POST['table_no'];
$time=$_POST['time'];
$date=$_POST['date'];
$sql="insert into ordermenu(fullname,EMAIL,mobile,gender,table_no,time,date) value('$fullname','$Email','$mobile','$gender','$table_no','$time','$date')";

if ($conn->query($sql) === TRUE) {
    echo "Order save successfully";
} else {
    echo "Error creating table: " . $conn->error;



$conn->close();

}

?>