<?PHP
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Cofeeshop";
{
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);   
}
if(isset($_REQUEST["submit"]));
{
  $user=$_REQUEST["user"] ;
  $email=$_REQUEST["email"] ;
  $password=$_REQUEST["pass"] ;
    mysql_query("insert into hasan(user,email,password) values('$user','$email','$password')");
    
}
?>
<?php
 echo  
<html>
<body>
    <form  method="post" >
        
               Username:<input type="text" name="user" placeholder=" Enter Username"><br>

                   Email: <input type="email" name="email" placeholder="Enter your email"><br>

                    Password:<input type="Password" name="pass" placeholder="Enter Pasword"><br><br>
                <button type="submit" name="submit" value="insert">submit</button>
         
</form>
</body>
</html>;

?>
        
   