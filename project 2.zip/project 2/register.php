<?php include('server.php')?>

<html>
<head>
  <title>Register from</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
    <div >
        <form method="POST" action="register.php">
        <div class="loginbox">
                <img src="avatar-1606916_960_720.png" class="avatar"><br>
                <h1>Rigister  Please!</h1>
                <form method="post" action="login1.php">
                <p>Username</p>
                    <input type="text" name="Username" placeholder=" Enter Username">
                    <p>Email</p>
                    <input type="email" name="Email" placeholder="Enter your email">
                    <p>Password</p>
                    <input type="Password" name="" placeholder="Enter Pasword"><br><br>
         <button type="Submit" name="Submit" class="btn">Submit</button>
         
                    <a href="login1.php">sign in</a>
              </div>     
       </form>
    </body>
</html> 