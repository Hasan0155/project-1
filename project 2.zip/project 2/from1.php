

<html>
    <head>
        
        <title>Login From</title>
        <body>
        <link rel="Stylesheet" type="text/css" href="style.css">
            <div class="loginbox">
                <img src="avatar-1606916_960_720.png" class="avatar"><br>
                <h1>Login here Please!</h1>
                <form method="post" action="login.php">
                <p>Username</p>
                    <input type="text" name="" placeholder=" Enter Username">
                    <p>Email</p>
                    <input type="email" name="" placeholder="Enter your email">
                    <p>Password</p>
                    <input type="password" name="" placeholder="Enter Pasword"><br><br>
                    <input type="submit" name="" value="Login"><br>
                    <a href="#">Lost your password?</a> <br>
                    <a href="#">Have you Any Account??</a> 
                </form>
            
            </div>
        </body>
    </head>