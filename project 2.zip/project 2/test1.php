<?php
echo"misbah","<br>";
echo str_word_count("Hello world!"),"<br>";
echo strpos("Hello world!", "d");

$t = date("H");

echo 'H';

 
?>