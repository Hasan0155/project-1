<?php 
$Username="";
$Email="";
$Password="";
$errors=array();
$username = 'root';
$password = '';
$db = 'register';
$db=mysqli_connect('localhost','root','','register');
if(isset($_POST['Submit'])){
    $username=mysqli_real_escape_string($_POST['Username']); 
    $email=mysqli_real_escape_string($_POST['Email']); 
    $password=mysqli_real_escape_string($_POST['Password']); 
    if(count(erros)==0){
    $ql="insert into users(Username,Email,Password) values(' $username',' $email',$password)";
    mysqli_query($db,$sql);
}
}

?>