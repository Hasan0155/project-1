<?php
$Username=filter_input(INPUT_POST,'Username');
$Email=filter_input(INPUT_POST,'Email');
$Password=filter_input(INPUT_POST,'Password');
if(!empty($username)){
 if(!empty($password)){
 $servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";   
 
     // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);   
}   
else{
 $sql = "INSERT INTO data (username, email,password)
VALUES ('$Username', '$Email', '$Password')";  
 if ($conn->query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();   
}
 }
    
}
else{
    echo"username should be";
    die();
}
else{
    echo"username should be";
    die();
}

?>