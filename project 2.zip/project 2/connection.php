<?php
$username=filter_input(INPUT_POST,'Username');
$email=filter_input(INPUT_POST,'Email');
$password=filter_input(INPUT_POST,'Password');
if(!empty($username)){
 if(!empty($password)){
 $servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";   
 
     // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);   
}   
else{
 $sql = "INSERT INTO data (username, email,password)
VALUES ('$username', '$email', '$password')";  
 if ($conn->query($sql) === TRUE) {
    echo "New records created successfully";
}
    else {
    echo "Error: " . $sql . "<br>" . $conn->error; 
}

$conn->close();   
}
 }
else{
    echo"password should be required";
    die();
}    
}

else{
    echo"username should be required";
    die();
}

?>