<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="loginfrom";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	
if(isset($_post['Login'])){
$Username=$_post['Username'];
$Email=$_post['Email'];
$password=$_post['password'];
$sql="insert into friend(Username,Email,Password)values('$Username','$Email','$password')";
mysqli_query($conn,$sql);
echo 'data inserted';

} 
echo "Connected successfully";
?>