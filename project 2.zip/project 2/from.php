<?php
echo'
<!doctype html>
<html>
    <head>
        
        <title>Login From</title>
        <body>
        <link rel="Stylesheet" type="text/css" href="style.css">
            <div class="loginbox">
                <img src="avatar-1606916_960_720.png" class="avatar"><br>
                <h1>Login here Please!</h1>
                
				<form   method="post" action="connection.php">
                <p>username</p>
                    <input type="text" name="" placeholder=" Enter psername">
                    <p>email</p>
                    <input type="email" name="" placeholder="Enter your email">
                    <p>password</p>
                    <input type="password" name="" placeholder="Enter pasword"><br><br>
                    <input type="submit" name="" value="login"><br>
                    <a href="#">Lost your password?</a> <br>
                    <a href="#">Have you Any Account??</a> 
                </form>
            
            </div>
        </body>
    </head>
	</html>';
?>




