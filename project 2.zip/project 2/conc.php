<?php
//$link=mysqli_connect('localhost','root','');
//mysqli_select_db('cofeeshop'); 

$servername = "localhost";
$username = "root";
$password = "";
$dbname="cofeeshop";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";

$name=$_POST['user'];
$email=$_POST['email'];
$password=$_POST['pass'];
$sql="insert into hasan(user,email,password) value('$name','$email','$password')";


if ($conn->query($sql) === TRUE) {
    echo "Data save successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();



?>




