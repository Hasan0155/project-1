

<html>
    <head>
        
        <title>Login From</title>
        <body>
        <link rel="Stylesheet" type="text/css" href="style.css">
            <div class="loginbox">
                <img src="avatar-1606916_960_720.png" class="avatar"><br>
                <h1>Resister here</h1>
                <form  action="res.php" method="POST">
                <p>Fname</p>
                    <input type="text" Fname="Fname" placeholder=" Enter Fname">
                    <p>Lname</p>
                    <input type="text" name="Lname" placeholder="Enter Lname">
                    <p>Email</p>
                    <input type="email" name="email" placeholder="Enter your email">
                    <p>Password</p>
                    <input type="password" name="password" placeholder="Enter Pasword"><br><br>
                    <p>Confrom Password</p>
                    <input type="password" name="confrom_password" placeholder="confrom _Pasword"><br><br>
                    <input type="submit" name="" value="save"><br>
                   
                </form>
            
            </div>
        </body>
    </head>