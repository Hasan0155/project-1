<html>
<body>
	<p>Hello</p>
	<?php  echo "<html>
<body>
<p>Hello Under PHP</p>
</body>	

</html>";?>
</body>	

</html>