<?php
$servername="localhost";
$username="root";
$password="";
$dbname="login";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);   
}   

 $usern=$_POST['user'];
 $password=$_POST['psw'];
 $sql = "INSERT INTO data (username,password)
VALUES ('$usern', '$password')";  
 if ($conn->query($sql) === TRUE) {
    echo "Data save successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();


?>