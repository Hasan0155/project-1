<html>
<head>
<title>login from</title>
<link rel="stylesheet" type="text/css" href="login.css"> 
</head>

<body>

<form action="login.php" method="POST">
  <div class="imgcontainer">
    
  </div>

  <div class="container">
    
	<label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="user" required>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <button type="submit">Login</button>
    <input type="checkbox" checked="checked"> Remember me</br>
    
	<a href="https://ridoyahmed.000webhostapp.com/Hasan/email.php"><button type="button" class="cancelbtn">Send Email</button></a> 
     <a href=https://www.google.com.bd/maps/@24.2330564,89.8925974,15z?hl=en><button type="button" class="cancelbtn">Google maps</button></a>
	  <a href=https://www.facebook.com><button type="button" class="cancelbtn">Facebook</button></a>
	  <a href=www.twiter.com><button type="button" class="cancelbtn">twiter</button></a>
	   <a href=www.yeyoo!.com><button type="button" class="cancelbtn">Yeyoo!</button></a>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
   
  </form>
</body>
</html>
