<?php

?>


<?php 
echo '
<!doctype html>
<html>
	<head>
	<meta charset="utf-8">
	<title>
		Welcome to Banladesh train service.
	</title>
	<link rel="stylesheet" type="text/css" href="sky.css"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
    <style type="text/css">
	 body{
	 background-color:gray;
	 }
	 #txt{
	 background-color:linear-gradient(darkred 20%,red 80%);
	 }
	</style>

	</head>	
  <body onload="startTime()">
  <marquee behavior="alternate" bgcolor="#33E525">
     <h2> <font color="grown" font-size="absulute"> Welcome to Bangladesh Railway  Service </font></h2>
     </marquee>
	
 
  <header>
   	<div class="logo"><img src="llangollen-railways-train.png" width="250" height="90" align="left"/></div>
   </header>
	<nav class="nav">
    <ul>
		<li><a href="HOME.html">Home</a></li>
  	    <li><a href="https://ridoyahmed.000webhostapp.com/Hasan/email.php"">Get Email</a></li>
	    <li><a href="https://www.google.com.bd/maps/@24.2330564,89.8925974,15z?hl=en">Google maps</a></li>
   	<li><a href="#">Train Name</a>
   	<ul>
   	<li><a href="inter.html">Intercity</a></li>
   	<li><a href="kortua.html">kortua</a></li>	
   	<li><a href="rangpur.html">Rangpur Express</a></li>	
   	<li><a href="rajsahi.html">Rajshai Express</a></li>		
   	</ul>
   	</li>
   	<li><a href="#">Train No</a>
   	<ul>
   	<li><a href="T-0111.html">T-0111</a></li>	
   		<li><a href="#">T-0555</a></li>	
   			<li><a href="#">T-0777</a></li>	
   				<li><a href="#">T-0880</a></li>	
				
   	</ul>
   	
   	</li>
   	<li><a href="http://localhost/jdbc/Show.php">Time Schedule</a>
	
    </li>
   	<li><a href="http://localhost/Hasan/login1.php ">Information</a></li>
	<li><a href="http://localhost/login/login.php">login</a></li></br></br>
	
    </ul>
	 </nav><br><br><br>
    <marquee direction="right" scrollamount="40" onMouseMove="this.stop();" onMouseOut="this.start();"><br>
	  <img src="hornby-gnr-gresley-n2-class-1763-transparent-background.png" height="400" width="600">
      </marquee>
	 <marquee behavior="alternate" bgcolor="#33E525">
      <h2> Thanks For visiting my website</h2>
     </marquee>
	  </body>
	 </html>';
	?>