<?php 
include('dbcon.php');

$sql = "INSERT INTO Student (firstname, lastname, email)
VALUES ('Fazlul', 'Tanim', 'tanim.mbstu@gmail.com')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


?>