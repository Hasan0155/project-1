<?php
include('dbcon.php');
$sql = "SELECT Train-Name, Start-place,Time FROM Train Schedule";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["Train-Name"]. $row["Start-place"]. $row["Time"];
    }
} 
$conn->close();

?>
